package com.demo.CRUDApplicationAdmin.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.CRUDApplicationAdmin.model.User;
import com.demo.CRUDApplicationAdmin.services.UserServices;

@RestController
@RequestMapping("/project1")
public class UserController {

	
	@Autowired
	private UserServices userServices;
	
	
	//http://localhost:8011/project1/welcome
	@GetMapping("/welcome")
	public String welcome() {
		return "Welcome to Project - 1";
	}
	
	//http://localhost:8012/project1/getData
	@GetMapping("/getData")
	public ResponseEntity<List<User>> getData(){
		List<User> users = userServices.getUser();
		System.out.println(users);
		return ResponseEntity.ok(users);
	}
	
	//http://localhost:8012/project1/add
	@PostMapping("/add")
	public ResponseEntity<User> addUser(@RequestBody User userDetails){
		User user = userServices.addUser(userDetails);
		return ResponseEntity.ok(user);
	}
	
	@GetMapping("/getData/{id}")
	public ResponseEntity<Optional<User>> getUserById(@PathVariable("id") int id) {
		Optional<User> user = userServices.getUserById(id);
		return ResponseEntity.ok(user);
	}
	
//	@GetMapping("/{id}")
//	public User getUserById(@PathVariable("id") int id) {
//		User user = userServices.getUserById(id);
//		return user;
//	}
	
	
	//http://localhost:8012/project1/delete/{id}
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteById(@PathVariable int id){
		userServices.deleteUser(id);
		return ResponseEntity.ok("Successfully deleted");
	}
	
	@DeleteMapping("/deleteByName/{name}")
	public ResponseEntity<String> deleteByUserName(@PathVariable String name){
		userServices.deleteByName(name);
		return ResponseEntity.ok("Successfully deleted");
	}
	
	@PutMapping("/update/{id}")
	public User update(@RequestBody User user , @PathVariable("id") int id) {
//		User user2 = userServices.updateUser(id, user);
		User user2 = userServices.updateUser(id, user);
		return user2;
	}
	
	//http://localhost:8012/project1/update2/{id}
	@PutMapping("/update2/{id}")
	public User update2(@RequestBody User user , @PathVariable("id") int id) {

		user.setId(id);
		User user2 = userServices.updateUser2(user);
		return user2;
	}
	
	
}
