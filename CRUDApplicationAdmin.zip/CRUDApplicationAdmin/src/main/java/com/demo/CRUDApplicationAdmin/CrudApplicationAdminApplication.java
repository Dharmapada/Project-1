package com.demo.CRUDApplicationAdmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudApplicationAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudApplicationAdminApplication.class, args);
		System.out.println("Hello World");
	}

}
