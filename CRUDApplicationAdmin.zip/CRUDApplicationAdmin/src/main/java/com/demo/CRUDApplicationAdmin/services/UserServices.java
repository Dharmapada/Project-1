package com.demo.CRUDApplicationAdmin.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.CRUDApplicationAdmin.model.User;
import com.demo.CRUDApplicationAdmin.repository.UserRepository;

@Service
public class UserServices {

	@Autowired
	private UserRepository userRepo;
	
	public List<User> getUser(){
		List<User> users = userRepo.findAll();
		return users;
	}
	
	public User addUser(User userDetails) {
		User user = userRepo.save(userDetails);
		return user;
	}
	
	public Optional<User> getUserById(int id) {
		
		//User user = userRepo.getById(id);
		Optional<User> user = userRepo.findById(id);
//		return user;
		return user;
	}
	
	public void deleteUser(int id) {
		userRepo.deleteById(id);
	}
	
	public void deleteByName(String name) {
		userRepo.deleteByName(name);
	}
	
	public User updateUser(int id, User user) {
		User user2 = userRepo.getById(id);
		if(user2 != null) {
			return userRepo.save(user);
		}
		return user2;
	}
	
	
	public User updateUser2(User user) {
		return userRepo.save(user);
	}
	
	
	
}
